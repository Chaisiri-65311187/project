class ApplianceItem {
  String name;
  String brandModel;
  bool isOn; // เพิ่มสถานะเปิด/ปิด

  ApplianceItem(
      {required this.name, required this.brandModel, this.isOn = false});
}
