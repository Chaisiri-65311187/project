import 'package:flutter/material.dart';
import 'package:sembast/sembast.dart';
import 'package:sembast/sembast_io.dart';
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart';
import '../model/applianceItem.dart';

class ApplianceProvider with ChangeNotifier {
  final List<ApplianceItem> _appliances = [];
  Database? _db;
  final _store = intMapStoreFactory.store('appliances');

  List<ApplianceItem> get appliances => List.unmodifiable(_appliances);

  Future<void> initDatabase() async {
    print("Initializing Database...");
    if (_db != null) return; // ป้องกันการเรียกซ้ำ
    final dir = await getApplicationDocumentsDirectory();
    final dbPath = join(dir.path, 'appliances.db');
    _db = await databaseFactoryIo.openDatabase(dbPath);
    await _loadAppliances();
  }

  Future<void> _loadAppliances() async {
    print("Loading Appliances from Database...");
    if (_db == null) return;
    final records = await _store.find(_db!);
    _appliances.clear();
    for (var record in records) {
      _appliances.add(ApplianceItem(
        name: record['name'] as String,
        brandModel: record['brandModel'] as String,
        isOn: record['isOn'] as bool,
      ));
    }
    notifyListeners();
  }

  Future<void> addAppliance(String name, String brandModel) async {
    print("Adding Appliance: Name=\$name, BrandModel=\$brandModel");
    await initDatabase();
    if (_db == null) return;
    final newItem = ApplianceItem(name: name, brandModel: brandModel);
    await _store.add(_db!, {
      'name': name,
      'brandModel': brandModel,
      'isOn': newItem.isOn,
    });
    _appliances.add(newItem);
    notifyListeners();
  }

  Future<void> updateAppliance(
      ApplianceItem oldItem, String newName, String newBrandModel) async {
    await initDatabase();
    if (_db == null) return;
    int index = _appliances.indexOf(oldItem);
    if (index != -1) {
      _appliances[index] = ApplianceItem(
        name: newName,
        brandModel: newBrandModel,
        isOn: oldItem.isOn,
      );
      await _store.update(
        _db!,
        {'name': newName, 'brandModel': newBrandModel, 'isOn': oldItem.isOn},
        finder: Finder(filter: Filter.equals('name', oldItem.name)),
      );
      notifyListeners();
    }
  }

  Future<void> togglePower(ApplianceItem item) async {
    await initDatabase();
    if (_db == null) return;
    int index = _appliances.indexOf(item);
    if (index != -1) {
      _appliances[index] = ApplianceItem(
        name: item.name,
        brandModel: item.brandModel,
        isOn: !item.isOn,
      );
      await _store.update(
        _db!,
        {'isOn': !item.isOn},
        finder: Finder(filter: Filter.equals('name', item.name)),
      );
      notifyListeners();
    }
  }

  Future<void> removeAppliance(ApplianceItem item) async {
    await initDatabase();
    if (_db == null) return;
    _appliances.remove(item);
    await _store.delete(
      _db!,
      finder: Finder(filter: Filter.equals('name', item.name)),
    );
    notifyListeners();
  }
}
